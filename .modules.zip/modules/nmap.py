b="\33[34;1m"
r="\33[31;1m"
g="\33[32;1m"
y="\33[33;1m"
cyan="\33[36;1m"
wh="\33[33;0m"
c="{}[{}".format(y,r)
cr="{}]{}".format(y,b)
import os
class nmap():
	def banner(self):
		print("""
   {}01{} Fast Scan
   {}02{} OS Detect
   {}03{} Normal Scan
   {}04{} Ping Scan
   {}05{} UDP Scan
   {}00{} Back
""".format(c,cr,c,cr,c,cr,c,cr,c,cr,c,cr))
	def work(self):
		while True:
			mehdi = raw_input("{}[#_SharkFramework_#]{} : ".format(cyan,wh))
			if mehdi == "01":
				ip = raw_input("{}IP : ".format(cyan))
				os.system("nmap -F {}".format(ip))
			elif mehdi == "02":
				ip = raw_input("{}IP : ".format(cyan))
				os.system("nmap -O {}".format(ip))
			elif mehdi == "03":
				ip = raw_input("{}IP : ".format(cyan))
				os.system("nmap {}".format(ip))
			elif mehdi == "04":
				ip = raw_input("{}IP : ".format(cyan))
				os.system("nmap -Pn {}".format(ip))
			elif mehdi == "05":
				ip = raw_input("{}IP : ".format(cyan))
				os.system("nmap -U {}".format(ip))
			elif mehdi == "00":
				os.system("python2 $PREFIX/bin/sharkf")
			else:
				print("{}[-]{} Invalid choose : ".format(r,wh))

	
self = nmap()
self.banner()
self.work()
