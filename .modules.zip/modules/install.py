import sys
print("Hello Friends ! Installer Is Not Availble Please Wait V2")
sys.exit()
