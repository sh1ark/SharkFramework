b="\33[34;1m"
r="\33[31;1m"
g="\33[32;1m"
y="\33[33;1m"
cyan="\33[36;1m"
wh="\33[33;0m"
c="{}[{}".format(y,cyan)
cr="{}]{}".format(y,wh)
import os,time,sys
class main():
	def banner(self):
		os.system("clear")
		print("""{}
                         __
      o                 /' ) 
            hmmm !    /'   (Algerian {}Hackers !{}
                  __/'     )                       
   o      _.-~~~~'          ``---..__    
     _.--'  b)                       ``  
    (     _.      )).      `-._          
     `\|\|\|\|)-.....___.-     `-.      
       `---......_______,,,`.___.'----
                               sh1ark    
{}
                                    [99] Exit
-------------------------------------------------
|  {}01{} Payload Generator {}02{} Tools Installer  |
|  {}03{} Hacking Sessions  {}04{} Root Installer   |  
|  {}05{} SharkSQL          {}06{} SharkMSL         |  
|  {}07{} Nmap Scan         {}08{} Windows          |
-------------------------------------------------
""".format(y,wh,y,wh,c,cr,c,cr,c,cr,c,cr,c,cr,c,cr,c,cr,c,cr,c,cr))
	def payload(self):
		os.system("python2 .modules/.gen.py")
	def tool(self):
		os.system("python2 .modules/.install.py")
	def session(self):
		os.system("python2 .modules/.exploit.py")
	def root(self):
		os.system("python2 .modules/.fake.py")
	def sql(self):
		os.system("python2 .modules/.sql.py")
	def msl(self):
		os.system("python2 .modules/.msl.py")
	def nmap(self):
		os.system("python2 .modules/.nmap.py")
	def win(self):
		os.system("python2 .modules/.windows.py")
main().banner()
while True:
	self = main()
	mehdi = raw_input("[#_SharkFramework_#] : ")
	if mehdi == "01":
		self.payload()
	elif mehdi == "02":
		self.tool()
	elif mehdi == "03":
		self.session()
	elif mehdi == "04":
		self.root()
	elif mehdi == "05":
		self.sql()
	elif mehdi == "06":
		self.msk()
	elif mehdi == "07":
		self.nmap()
	elif mehdi == "08":
		self.win()
	elif mehdi == "00":
		print("[!] Exiting . . .(wait)")
		time.sleep(3)
		sys.exit()
	else:
		print("Invalid Choose!")
	
		
