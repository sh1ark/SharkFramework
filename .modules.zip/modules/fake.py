import os
import sys
b="\33[34;1m"
r="\33[31;1m"
g="\33[32;1m"
y="\33[33;1m"
cyan="\33[36;1m"
wh="\33[33;0m"
r = raw_input("Press Enter to continue ! ")
os.system("git clone https://github.com/Lexiie/termux-fakeroot")
os.chdir("termux-fakeroot")
os.system("apt install  ./fakeroot_1.0_aarch64.deb")
os.system("fakeroot")
os.system('whoami')
