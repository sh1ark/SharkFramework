b="\33[34;1m"
r="\33[31;1m"
g="\33[32;1m"
y="\33[33;1m"
cyan="\33[36;1m"
wh="\33[33;0m"
c="{}[{}".format(y,cyan)
cr="{}]{}".format(y,wh)
import os
import sys,time
class win():
	def banner(self):
		print("""
	{}01{} Ad-Hoc Creator
	{}02{} Ad-Hoc Starter
	{}03{} Shutdown Devices In Network
	{}04{} Shortuct Virus Cleaner
	{}00{} Back
""")
	def adhocc(self):
		name = raw_input("Name OF HostedNetwork : ")
		pwd = raw_input("Password : ")
		os.system("netsh wlan set hostednetwork mode=allow ssid={} key={}".format(name,pwd))
	def adhocs(self):
		t = raw_input("Press Enter To Continue ! ")
		os.system("netsh wlan start hostednetwork")
		print(g+"[+] Now Go To Sharing Center And Choose your Network ! ")
	def shut(self):
		print("[*] Get All IP's In Network (wait)")
		time.sleep(3)
		os.system("arp -a")
		print("[!] Now You Will See An Window Put The Target IP in ")
		os.system("shutdown -i")
	def virus(self):
		p = raw_input("Choose Disk Letter e.g [d] :")
		print("You Choose "+p)
		print(b+"[*] Cleaning (wait)")
		time.sleep(3)
		os.system("attrib -h -r -s /s /d "+p+":\*.*")
		print("Cleaning Succes ! ")
	def back(self):
		os.system("python2 $PREFIX/bin/shrkf")
	
win().banner()
while True:
	mehdi = raw_input("[#_SharkFramework_#] : ")
	if mehdi == "01":
		win().adhocc()
	elif mehdi == "02":
		win().adhocs()
	elif mehdi == "03":
		win().shut()
	elif mehdi == "04":
		win().virus()
	elif mehdi == "00":
		win().back()
		
