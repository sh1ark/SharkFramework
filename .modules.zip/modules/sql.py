import os,time
b="\33[34;1m"
r="\33[31;1m"
g="\33[32;1m"
y="\33[33;1m"
cyan="\33[36;1m"
wh="\33[33;0m"
c="{}[{}".format(y,r)
cr="{}]{}".format(y,b)
def ta():
	print("{}[INFO]{}Please Wait...!".format(cyan,wh))
	time.sleep(3)
	os.system("sh $PREFIX/bin/shark")
ta()
